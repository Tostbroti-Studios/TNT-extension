advancement revoke @s only tnt:tnt
execute at @s run summon tnt