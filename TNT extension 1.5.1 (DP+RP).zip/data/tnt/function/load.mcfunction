scoreboard objectives add super_tnt dummy super_tnt
scoreboard objectives add test_tnt dummy test_tnt
scoreboard players set @a test_tnt 1000
say §l §4TNT extension successfully installed 
say §l §3Run /function tnt:give_tnt to receive every new custom tnt tool
say §l §3Or do /loot give [player] loot tnt:[item] get a specific item (or simply craft it 😊) 