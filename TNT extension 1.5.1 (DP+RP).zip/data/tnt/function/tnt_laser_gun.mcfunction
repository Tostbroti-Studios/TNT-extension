execute as @e[nbt={weapon:{components:{"minecraft:custom_data":{RailgunBow:1b}}}}] at @s run summon interaction ~ ~ ~ {Tags:["RailgunArrow"]}
execute as @e[tag=RailgunArrow] at @s if entity @e[nbt={weapon:{components:{"minecraft:custom_data":{RailgunBow:1b}}}}] run data modify entity @s Rotation set from entity @p Rotation
execute as @e[tag=RailgunArrow] at @s if entity @e[nbt={weapon:{components:{"minecraft:custom_data":{RailgunBow:1b}}}}] run tp @s ^ ^ ^5
execute as @e[tag=RailgunArrow] at @s run tp @s ^ ^ ^1
execute as @e[tag=RailgunArrow] at @s run summon tnt ~ ~ ~ {fuse:0}
kill @e[nbt={weapon:{components:{"minecraft:custom_data":{RailgunBow:1b}}}}]
execute as @e[tag=RailgunArrow] at @s unless entity @a[distance=..150] run kill @s
