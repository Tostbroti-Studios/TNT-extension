execute as @s run summon tnt_minecart ~ ~ ~ {explosion_power:40}
scoreboard players add @s super_tnt 1
execute if score @s super_tnt <= @s test_tnt run function tnt:super_tnt_recursive
execute if score @s super_tnt >= @s test_tnt run scoreboard players set @s super_tnt 0