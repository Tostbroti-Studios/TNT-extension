advancement revoke @s only tnt:tnt_minecart
execute at @s run summon tnt_minecart