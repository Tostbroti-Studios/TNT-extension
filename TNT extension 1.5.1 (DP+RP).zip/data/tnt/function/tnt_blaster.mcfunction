summon tnt
summon falling_block
kill @s