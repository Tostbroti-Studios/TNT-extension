execute as @e[type=arrow,nbt={inGround:1b,weapon:{components:{"minecraft:custom_data":{tnt_blaster:1b}}}}] at @s run function tnt:tnt_blaster
function tnt:tnt_laser_gun