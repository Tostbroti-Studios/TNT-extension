function tnt:super_tnt_recursive
schedule function tnt:advancement_revoke 5s replace